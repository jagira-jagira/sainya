<?php
ob_start();
session_start();
ob_clean();
if(!isset($_SERVER['HTTP_REFERER'])){
    header('location: index.php');
    exit;
}
if ($_SESSION['uname']) {
	echo "welcome ". $_SESSION['uname'];
	#further enhancement in the site goes here
}else{
	ob_start();
	header('location: index.php');
	ob_clean();
}



?>
